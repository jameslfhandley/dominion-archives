﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace senwes_project2
{
 public class EmployeeList2
 {
  public List<Employee> Employee2 { get; set; }
 }
}
