﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace senwes_project2.Controllers
{
 public class route2Controller : Controller
 {
  public List<Employee> empData; // relatable list array
  public employee_class0[] Employee0;
  public employee_class0[] array5year;
  public employee_class0[] array30year;

  public route2Controller()
  {
	empData = null;

	if (empData == null)
	{
	 string jsonFilePath = @"Data\Employee.json";
	 string json = System.IO.File.ReadAllText(jsonFilePath);

	 empData = JsonConvert.DeserializeObject<List<Employee>>(json);
	}

	

  }

  [HttpGet]
  public IEnumerable fetch_five()
  {

   int count1 = 0; // alter to test a manageable amount
   count1 = empData.Count();

   int array_count0 = 0;

   string target0 = "";
   string target1 = "";
   int pos0 = 0;
   int pos1 = 0;

   int compare0 = 0;
   for (int i = 0; i < count1; i++)
   {
    pos0 = empData[i].DateOfJoining.IndexOf("/");
    target0 = empData[i].DateOfJoining.Substring(pos0 + 1);
    pos1 = target0.IndexOf("/");
    target1 = target0.Substring(pos1 + 1);

    compare0 = Int32.Parse(target1);

    if (compare0 >= 2015)
    {
     array_count0++;
    }
   }


   array5year = new employee_class0[array_count0];

   int iterate1 = 0;
   for (int i = 0; i < count1; i++)
   {
    pos0 = empData[i].DateOfJoining.IndexOf("/");
    target0 = empData[i].DateOfJoining.Substring(pos0 + 1);
    pos1 = target0.IndexOf("/");
    target1 = target0.Substring(pos1 + 1);
    compare0 = Int32.Parse(target1);

    if (compare0 >= 2015)
    {
     array5year[iterate1] = new employee_class0(empData[i].EmpID, empData[i].FirstName, empData[i].LastName
         , empData[i].Gender, empData[i].EMail, empData[i].DateOfBirth, empData[i].Age, empData[i].DateOfJoining,
         empData[i].YearsInCompany, empData[i].Salary, empData[i].LastIncrease, empData[i].SSN, empData[i].PhoneNo
         , empData[i].City, empData[i].State, empData[i].Zip, empData[i].UserName);


     iterate1++;
    }
   }

   return array5year;
  }

  [HttpGet]
  public IEnumerable fetch_thirty()
  {
   int count1 = 0; // alter to test a manageable amount
   count1 = empData.Count();
   double current_age0 = 0;
   int array_count0 = 0;
   int iterate1 = 0;
   for (int i = 0; i < count1; i++)
   {
    current_age0 = empData[i].Age;

    if (current_age0 >= 30)
    {
     array_count0++;
    }
   }


   array30year = new employee_class0[array_count0];
   for (int i = 0; i < count1; i++)
   {

    if (empData[i].Age >= 30)
    {
     array30year[iterate1] = new employee_class0(empData[i].EmpID, empData[i].FirstName, empData[i].LastName
         , empData[i].Gender, empData[i].EMail, empData[i].DateOfBirth, empData[i].Age, empData[i].DateOfJoining,
         empData[i].YearsInCompany, empData[i].Salary, empData[i].LastIncrease, empData[i].SSN, empData[i].PhoneNo
         , empData[i].City, empData[i].State, empData[i].Zip, empData[i].UserName);


     iterate1++;
    }
   }

   return array30year;
  }

  [HttpGet]
  public IEnumerable fetch_treasure()
  {
   return fetch_salary0("treasure");
  }

  [HttpGet]
  public IEnumerable fetch_nona()
  {
   return fetch_salary0("nona");
  }

  List<TreasureEmployee> fetch_salary0(string target0)
  {
   List<TreasureEmployee> returnObj = new List<TreasureEmployee>() { };
   var employees = empData.Where(a => a.FirstName.ToLower() == target0);

   foreach (Employee T in employees)
   {
    TreasureEmployee em = new TreasureEmployee
    {
     EmpID = T.EmpID,
     FirstName = T.FirstName,
     LastName = T.LastName,
     Salary = T.Salary
    };
    returnObj.Add(em);
   }
   return returnObj;
  }

  public IEnumerable fetch_cities()
  {
   List<City_list1> returnObj = new List<City_list1>() { };
   
    var employees = empData.OrderBy(a => a.City).ToList();

    foreach (Employee i in employees)
    {
    City_list1 current1 = new City_list1(i.City);
    returnObj.Add(current1);
    }
    return returnObj;
  }

}



}
