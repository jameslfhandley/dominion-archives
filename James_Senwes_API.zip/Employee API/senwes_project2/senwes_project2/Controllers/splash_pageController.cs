﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace senwes_project2.Controllers
{
 public class splash_pageController : Controller
 {
  [HttpGet]
  public IActionResult Index()
  {
	return Ok("The API is running.\nIf running on localhost, you can run the accompanying Windows Form and enter the Local Host port.\n\nThen the Form will give options to fetch the various Employee Output needed for this Exercise.\n\nHere are the Route paths to form the query filters:\n\nhttps://localhost:44390/route1/fetch_emp/159108\nFetch Employee by select ID\n\nhttps://localhost:44390/route2/fetch_five\nFetch employees who joined the company over 5 years ago, from 2021.\n\nhttps://localhost:44390/route2/fetch_thirty.\nFetch all employees older than 30.\n\nhttps://localhost:44390/route3/fetch_female\nhttps://localhost:44390/route3/fetch_male\nFetch 10 Male Or Female Employees with the highest salaries.\n\nhttps://localhost:44390/route1/fetch_emp_search?fname=shana&lname=buck&city=las+vegas\nFetch specific employees with criteria, first name, last name and city.\n\nhttps://localhost:44390/route2/fetch_treasure\nFetch employee salary by the name 'Treasure'.\n\nhttps://localhost:44390/route2/fetch_cities\nFetch all employees entries but only return city fields.");
  }
 }
}
