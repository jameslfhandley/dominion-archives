﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace senwes_project2.Controllers
{
 public class route3Controller : Controller
 {

  public List<Employee> empData; // relatable list array
  public LoadData loadData0; // what the constructor returns - IEnumerable
  public employee_class0[] Employee0;
  public employee_class0[] array_gender1;

  [HttpGet]
  public IEnumerable fetch_male()
  {
   return query_gender0("M");
   }

  [HttpGet]
  public IEnumerable fetch_female()
  {
   return query_gender0("F");
  }


  List<Employee> query_gender0(string gender)
   {
    loadData0 = new LoadData();
    EmployeeList1 returnObj = new EmployeeList1() { };


    IEnumerable<Employee> emp = loadData0.LoadEmployeeData().OrderByDescending(a => a.Salary);
    var returnObj2 = emp.Where(a => a.Gender.ToLower() == gender.ToLower()).Take(10).Select(a => new Employee
    {
     Age = a.Age,
     City = a.City,
     DateOfBirth = a.DateOfBirth,
     DateOfJoining = a.DateOfJoining,
     EMail = a.EMail,
     EmpID = a.EmpID,
     FirstName = a.FirstName,
     Gender = a.Gender,
     LastIncrease = a.LastIncrease,
     LastName = a.LastName,
     PhoneNo = a.PhoneNo,
     Salary = a.Salary,
     SSN = a.SSN,
     State = a.State,
     UserName = a.UserName,
     YearsInCompany = a.YearsInCompany,
     Zip = a.Zip

    }).ToList();

   return returnObj2;
  }


 }
}
