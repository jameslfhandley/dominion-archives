﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace senwes_project2.Controllers
{
 public class route1Controller : Controller
 {
  public List<Employee> empData; // relatable list array
  public LoadData loadData; // what the constructor returns - IEnumerable
  public employee_class0[] Employee0;
  

public route1Controller()
  {
	empData = null;
	if (empData == null)
	{
	 string jsonFilePath = @"Data\Employee.json";
	 string json = System.IO.File.ReadAllText(jsonFilePath);

	 empData = JsonConvert.DeserializeObject<List<Employee>>(json);
	}
	loadData = new LoadData();
  }

  [HttpGet]
  public IEnumerable fetch_emp(int id)
  {
	if (id <= 0)
	{ id = 0; }
	
	var employees1 = empData.Where(a => 
	 (a.EmpID == id)
	 ).Select(a => new Employee
	 {
	  Age = a.Age,
	  City = a.City,
	  DateOfBirth = a.DateOfBirth,
	  DateOfJoining = a.DateOfJoining,
	  EMail = a.EMail,
	  EmpID = a.EmpID,
	  FirstName = a.FirstName,
	  Gender = a.Gender,
	  LastIncrease = a.LastIncrease,
	  LastName = a.LastName,
	  PhoneNo = a.PhoneNo,
	  Salary = a.Salary,
	  SSN = a.SSN,
	  State = a.State,
	  UserName = a.UserName,
	  YearsInCompany = a.YearsInCompany,
	  Zip = a.Zip

	 }).ToList();

	return (employees1);

  }

  [HttpGet]
  public IEnumerable fetch_emp_search(string fname, string lname, string city)
  {
	if (fname == null)
	{ fname = ""; }
	else
	{
	 fname = HttpUtility.UrlDecode(fname);
	}

	if (lname == null)
	{ lname = ""; }
	else
	{
	 lname = HttpUtility.UrlDecode(lname);
	}

	if (city == null)
	{ city = ""; }
	else
	{
	 city = HttpUtility.UrlDecode(city);
	}

	var employees1 = empData.Where(a => (
	 (a.FirstName.ToLower() == fname.ToLower() ) || (a.LastName.ToLower() == lname.ToLower())  || (a.City.ToLower() == city.ToLower() ) )
	 ).Select(a => new Employee
	 {
	  Age = a.Age,
	  City = a.City,
	  DateOfBirth = a.DateOfBirth,
	  DateOfJoining = a.DateOfJoining,
	  EMail = a.EMail,
	  EmpID = a.EmpID,
	  FirstName = a.FirstName,
	  Gender = a.Gender,
	  LastIncrease = a.LastIncrease,
	  LastName = a.LastName,
	  PhoneNo = a.PhoneNo,
	  Salary = a.Salary,
	  SSN = a.SSN,
	  State = a.State,
	  UserName = a.UserName,
	  YearsInCompany = a.YearsInCompany,
	  Zip = a.Zip

	 }).ToList();

	 return (employees1);


  }
 }

}
