﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace senwes_project2
{
 public class City_list1
 {

  public City_list1()
  {

  }

  public City_list1(string City0)
  {
	this.City = City0;
  }

  public string City { get; set; }

 }


}
