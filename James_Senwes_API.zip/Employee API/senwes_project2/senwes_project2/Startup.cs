using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace senwes_project2
{

 public class Startup
 {
  public Startup(IConfiguration configuration)
  {
	Configuration = configuration;
  }

  public IConfiguration Configuration { get; }

  // This method gets called by the runtime. Use this method to add services to the container.
  public void ConfigureServices(IServiceCollection services)
  {


	services.AddControllers();
  }

  // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
  public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
  {
	if (env.IsDevelopment())
	{
	 app.UseDeveloperExceptionPage();
	}

	app.UseHttpsRedirection();

	app.UseRouting();

	app.UseAuthorization();

	app.UseEndpoints(endpoints =>
	{
	 endpoints.MapControllers();
	});

app.UseEndpoints(endpoints =>
	{
	 endpoints.MapControllerRoute(name: "default",pattern: "{controller=Second}/{action=Fetch}/{id?}");
	 endpoints.MapControllerRoute(name: "default", pattern: "{controller=route1}/{action=fetch_emp}/{id?}");
	 //endpoints.MapControllerRoute(name: "default", pattern: "{controller=route1}/{action=fetch_emp_search}/{fname?}/{lname?}/{city?}");
	 //variable parameters passed in conventional URL format instead

	 endpoints.MapControllerRoute(name: "default", pattern: "{controller=route1}/{action=fetch_emp_search}");
	 endpoints.MapControllerRoute(name: "default", pattern: "{controller=route2}/{action=fetch_five}");
	 endpoints.MapControllerRoute(name: "default", pattern: "{controller=route2}/{action=fetch_thirty}");
	 endpoints.MapControllerRoute(name: "default", pattern: "{controller=route2}/{action=fetch_treasure}");
	 endpoints.MapControllerRoute(name: "default", pattern: "{controller=route2}/{action=fetch_nona}");
	 endpoints.MapControllerRoute(name: "default", pattern: "{controller=route2}/{action=fetch_cities}");

	 endpoints.MapControllerRoute(name: "default", pattern: "{controller=route3}/{action=fetch_male}");
	 endpoints.MapControllerRoute(name: "default", pattern: "{controller=route3}/{action=fetch_female}");



	 endpoints.MapControllerRoute(name: "default", pattern: "{controller=splash_page}/{action=Index}");
	 
	});

}
 }




}
