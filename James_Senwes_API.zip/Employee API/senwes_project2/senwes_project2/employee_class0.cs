﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace senwes_project2
{
 public class employee_class0
 {

  public employee_class0()
  {

  }

  public employee_class0(int EmpID0, string FirstName0, string LastName0, string Gender0, string EMail0, string DateOfBirth0,
      double Age0, string DateOfJoining0, double YearsInCompany0, int Salary0, string LastIncrease0, string SSN0,
      string PhoneNo0, string City0, string State0, int Zip0, string UserName0)
  {
   EmpID = EmpID0;
   this.FirstName = FirstName0;
   this.LastName = LastName0;
   this.Gender = Gender0;
   this.EMail = EMail0;
   this.DateOfBirth = DateOfBirth0;
   this.Age = Age0;
   this.DateOfJoining = DateOfJoining0;
   this.YearsInCompany = YearsInCompany0;
   this.Salary = Salary0;
   this.LastIncrease = LastIncrease0;
   this.SSN = SSN0;
   this.PhoneNo = PhoneNo0;
   this.City = City0;
   this.State = State0;
   this.Zip = Zip0;
   this.UserName = UserName0;
  }

  public int EmpID { get; set; }
  public string FirstName { get; set; }
  public string LastName { get; set; }
  public string Gender { get; set; }
  public string EMail { get; set; }
  public string DateOfBirth { get; set; }
  public double Age { get; set; }
  public string DateOfJoining { get; set; }
  public double YearsInCompany { get; set; }
  public int Salary { get; set; }
  public string LastIncrease { get; set; }
  public string SSN { get; set; }
  public string PhoneNo { get; set; }
  public string City { get; set; }
  public string State { get; set; }
  public int Zip { get; set; }
  public string UserName { get; set; }

 }
}
