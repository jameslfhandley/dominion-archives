﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace senwes0
{
 public class Route1_fetch_empid
 {

  public Route1_fetch_empid(ref DataGridView Datasource0,string criteria0,ref string port_no0)
  {
   int criteria1;
   criteria1 = 0;

   try
   {
    criteria1 = Int32.Parse(criteria0);
   }
   catch (FormatException error0)
   {
    MessageBox.Show(error0.Message);
   }


   List<Employee> empdata0;
   string convert0 = "";
   var json1 = new WebClient().DownloadString("https://localhost:"+port_no0+"/route1/fetch_emp/" + criteria1);
   
   convert0 = json1;
   empdata0 = JsonConvert.DeserializeObject<List<Employee>>(json1);
   Datasource0.DataSource = empdata0;


  }
 }


}