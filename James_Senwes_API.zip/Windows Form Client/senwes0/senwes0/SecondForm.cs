﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using System.IO;
using System.Net;
using System.Net.Http;

namespace senwes0
{



 public partial class SecondForm : Form
 {
  public employee_class0[] array_test0; // DEBUG Test Array
  public List<Employee> _empData;
  public CurrencyManager currencyManager0 = null;
  public LoadData _loadData;

  public employee_class0[] array5year;
  public employee_class0[] array30year;
  public employee_class0[] arrayGenderCount0;
  public employee_class0[] arrayNameCity0;
  public TreasureEmployee[] arrayTreasure0;
  public City_form1[] arrayCityList0;

  public Route1_fetch_empid route1_action;
  public Route2_5years route2_action;
  public Route3_30years route3_action;
  public Route4_select_gender route4_action;
  public Route5_search_criteria route5_action;
  public Route6_fetch_salaries route6_action;
  public Route7_output_cities route7_action;

  public string global_port0 = "44390";  

  public SecondForm(string port_number1)
  {
   global_port0 = port_number1;
   InitializeComponent();
   _empData = null;

   if (_empData == null)
   {
    string jsonFilePath = @"Data\Employee.json";
    string json = File.ReadAllText(jsonFilePath);

    _empData = JsonConvert.DeserializeObject<List<Employee>>(json);
   }
   currencyManager0 = (CurrencyManager)emp_id_output0.BindingContext[_empData];

  }


  private void input_1_TextChanged(object sender, EventArgs e)
  {

  }

  private void get_id_button0_Click(object sender, EventArgs e)
  {
   string criteria0;
   criteria0 = input_1.Text;
   route1_action = new Route1_fetch_empid(ref emp_id_output0,criteria0,ref global_port0);

  }

  private void emp_id_output0_CellContentClick(object sender, DataGridViewCellEventArgs e)
  {

  }



  public void debug_button0_Click(object sender, EventArgs e)
  {
   List<Employee> empdata0;
   string convert0 = "";
    var json1 = new WebClient().DownloadString("https://localhost:44390/route1/fetch_emp/850297");
    MessageBox.Show(" - " + json1);
   convert0 = json1;
   empdata0 = JsonConvert.DeserializeObject<List<Employee>>(json1);
   emp_id_output0.DataSource = empdata0;

  }

  private void datagrid_5years_CellContentClick(object sender, DataGridViewCellEventArgs e)
  {

  }

  public void joindate_button0_Click(object sender, EventArgs e)
  {
   route2_action = new Route2_5years(ref dataGrid_city0, ref global_port0);
  }

  private void button1_Click(object sender, EventArgs e) // OLDER THAN 30 button
  {
   route3_action = new Route3_30years(ref dataGrid_city0, ref global_port0);
  }

  private void button_fetch_female_salary_Click(object sender, EventArgs e)
  {
   route4_action = new Route4_select_gender("fetch_female", ref dataGrid_city0, ref global_port0);
  }

  private void button_salary_gender0_Click(object sender, EventArgs e)
  {
   route4_action = new Route4_select_gender("fetch_male", ref dataGrid_city0, ref global_port0);
  }

  private void input_name0_TextChanged(object sender, EventArgs e)
  {

  }

  private void input_surname0_TextChanged(object sender, EventArgs e)
  {

  }

  private void input_city0_TextChanged(object sender, EventArgs e)
  {

  }

  private void button_search_criteria0_Click(object sender, EventArgs e)
  {
   string compare0 = input_name0.Text;
   string compare1 = input_surname0.Text;
   string compare2 = input_city0.Text;

   route5_action = new Route5_search_criteria(compare0, compare1, compare2,ref dataGrid_city0, ref global_port0);

  }

  private void dataGrid_city0_CellContentClick(object sender, DataGridViewCellEventArgs e)
  {

  }

  private void button_treasure0_Click(object sender, EventArgs e)
  {
   MessageBox.Show("ATTENTION : The table appears to contain no employee named 'Treasure'. No results will be found.");
   route6_action = new Route6_fetch_salaries("treasure",ref dataGrid_city0, ref global_port0);

  }


  private void button_buck0_Click(object sender, EventArgs e)
  {
   route6_action = new Route6_fetch_salaries("nona",ref dataGrid_city0, ref global_port0);
  }

  private void button_city_list0_Click(object sender, EventArgs e)
  {
   route7_action = new Route7_output_cities(ref dataGrid_city0, ref global_port0);
  }

 }

}