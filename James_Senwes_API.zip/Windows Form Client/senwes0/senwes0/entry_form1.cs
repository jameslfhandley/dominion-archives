﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace senwes0
{
 public partial class entry_form1 : Form
 {
  public entry_form1()
  {
	InitializeComponent();
	this.textBox3.Text = "44390";
  }

  private void textBox1_TextChanged(object sender, EventArgs e)
  {

  }

  private void textBox2_TextChanged(object sender, EventArgs e)
  {

  }

  private void textBox3_TextChanged(object sender, EventArgs e)
  {

  }

  private void button_login1_Click(object sender, EventArgs e)
  {
	string port_arg1 = textBox3.Text;
	SecondForm form2 = new SecondForm(port_arg1);
	form2.ShowDialog();
  }
 }
}
