﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace senwes0
{
 public class EmployeeList1
 {

   public List<Employee> Employee1 { get; set; }
}


}
