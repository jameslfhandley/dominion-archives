﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace senwes0
{
  public class TreasureEmployee
  {

   public TreasureEmployee()
   {

   }

   public TreasureEmployee(int EmpID0, string FirstName0, string LastName0, int Salary0)
   {
    EmpID = EmpID0;
    this.FirstName = FirstName0;
    this.LastName = LastName0;
    this.Salary = Salary0;
   }

   public int EmpID { get; set; }
   public string FirstName { get; set; }
   public string LastName { get; set; }
   public int Salary { get; set; }

  }
 }
