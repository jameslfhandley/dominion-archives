﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace senwes0
{
 public class Route6_fetch_salaries
 {
  public Route6_fetch_salaries(string arg1,ref DataGridView Datasource0, ref string port_no0)
  {
   if (arg1 == "treasure")
   {
    List<TreasureEmployee> empdata0;
    string convert0 = "";
    var json1 = new WebClient().DownloadString("https://localhost:" + port_no0 + "/route2/fetch_treasure");

    convert0 = json1;
    empdata0 = JsonConvert.DeserializeObject<List<TreasureEmployee>>(json1);
    Datasource0.DataSource = empdata0;
   }
else if (arg1 == "nona")
   {
    List<TreasureEmployee> empdata0;
    string convert0 = "";
    var json1 = new WebClient().DownloadString("https://localhost:" + port_no0 + "/route2/fetch_nona");

    convert0 = json1;
    empdata0 = JsonConvert.DeserializeObject<List<TreasureEmployee>>(json1);
    Datasource0.DataSource = empdata0;
   }

  }
 }

}
