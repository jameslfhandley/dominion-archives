﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Linq;
using System.Net;
using Newtonsoft.Json;

namespace senwes0
{
 public class Route3_30years
 {

 public Route3_30years(ref DataGridView Datasource0, ref string port_no0)
{
   List<Employee> empdata0;
   string convert0 = "";
   var json1 = new WebClient().DownloadString("https://localhost:" + port_no0 + "/route2/fetch_thirty");

   convert0 = json1;
   empdata0 = JsonConvert.DeserializeObject<List<Employee>>(json1);
   Datasource0.DataSource = empdata0;


  }

 }
}
