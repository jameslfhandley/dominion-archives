﻿namespace senwes0
{
    partial class SecondForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
	this.label1 = new System.Windows.Forms.Label();
	this.input_1 = new System.Windows.Forms.TextBox();
	this.get_id_button0 = new System.Windows.Forms.Button();
	this.emp_id_box = new System.Windows.Forms.GroupBox();
	this.emp_id_output0 = new System.Windows.Forms.DataGridView();
	this.emp_id = new System.Windows.Forms.DataGridViewTextBoxColumn();
	this.firstname = new System.Windows.Forms.DataGridViewTextBoxColumn();
	this.lastname = new System.Windows.Forms.DataGridViewTextBoxColumn();
	this.emp_id_para0 = new System.Windows.Forms.Label();
	this.debug_button0 = new System.Windows.Forms.Button();
	this.joindate_button0 = new System.Windows.Forms.Button();
	this.group_employees_5years = new System.Windows.Forms.GroupBox();
	this.button_fetch_female_salary = new System.Windows.Forms.Button();
	this.label2 = new System.Windows.Forms.Label();
	this.button_salary_gender0 = new System.Windows.Forms.Button();
	this.button1 = new System.Windows.Forms.Button();
	this.label_salary_gender0 = new System.Windows.Forms.Label();
	this.label_fetch_age = new System.Windows.Forms.Label();
	this.label_employee5years = new System.Windows.Forms.Label();
	this.label3 = new System.Windows.Forms.Label();
	this.label4 = new System.Windows.Forms.Label();
	this.label5 = new System.Windows.Forms.Label();
	this.input_name0 = new System.Windows.Forms.TextBox();
	this.input_surname0 = new System.Windows.Forms.TextBox();
	this.input_city0 = new System.Windows.Forms.TextBox();
	this.dataGrid_city0 = new System.Windows.Forms.DataGridView();
	this.button_search_criteria0 = new System.Windows.Forms.Button();
	this.label6 = new System.Windows.Forms.Label();
	this.button_treasure0 = new System.Windows.Forms.Button();
	this.label7 = new System.Windows.Forms.Label();
	this.button_buck0 = new System.Windows.Forms.Button();
	this.button_city_list0 = new System.Windows.Forms.Button();
	this.label8 = new System.Windows.Forms.Label();
	this.emp_id_box.SuspendLayout();
	((System.ComponentModel.ISupportInitialize)(this.emp_id_output0)).BeginInit();
	this.group_employees_5years.SuspendLayout();
	((System.ComponentModel.ISupportInitialize)(this.dataGrid_city0)).BeginInit();
	this.SuspendLayout();
	// 
	// label1
	// 
	this.label1.AutoSize = true;
	this.label1.Location = new System.Drawing.Point(6, 21);
	this.label1.Name = "label1";
	this.label1.Size = new System.Drawing.Size(98, 13);
	this.label1.TabIndex = 1;
	this.label1.Text = "Enter Employee ID:";
	// 
	// input_1
	// 
	this.input_1.Location = new System.Drawing.Point(117, 18);
	this.input_1.Name = "input_1";
	this.input_1.Size = new System.Drawing.Size(132, 20);
	this.input_1.TabIndex = 2;
	this.input_1.TextChanged += new System.EventHandler(this.input_1_TextChanged);
	// 
	// get_id_button0
	// 
	this.get_id_button0.Location = new System.Drawing.Point(117, 44);
	this.get_id_button0.Name = "get_id_button0";
	this.get_id_button0.Size = new System.Drawing.Size(132, 23);
	this.get_id_button0.TabIndex = 3;
	this.get_id_button0.Text = "Get Employee by ID";
	this.get_id_button0.UseVisualStyleBackColor = true;
	this.get_id_button0.Click += new System.EventHandler(this.get_id_button0_Click);
	// 
	// emp_id_box
	// 
	this.emp_id_box.Controls.Add(this.emp_id_output0);
	this.emp_id_box.Controls.Add(this.emp_id_para0);
	this.emp_id_box.Controls.Add(this.debug_button0);
	this.emp_id_box.Controls.Add(this.get_id_button0);
	this.emp_id_box.Controls.Add(this.input_1);
	this.emp_id_box.Controls.Add(this.label1);
	this.emp_id_box.Location = new System.Drawing.Point(21, 24);
	this.emp_id_box.Name = "emp_id_box";
	this.emp_id_box.Size = new System.Drawing.Size(425, 167);
	this.emp_id_box.TabIndex = 5;
	this.emp_id_box.TabStop = false;
	this.emp_id_box.Text = "Fetch single employee via ID";
	// 
	// emp_id_output0
	// 
	this.emp_id_output0.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
	this.emp_id_output0.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.emp_id,
            this.firstname,
            this.lastname});
	this.emp_id_output0.Location = new System.Drawing.Point(6, 86);
	this.emp_id_output0.Name = "emp_id_output0";
	this.emp_id_output0.Size = new System.Drawing.Size(413, 63);
	this.emp_id_output0.TabIndex = 5;
	this.emp_id_output0.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.emp_id_output0_CellContentClick);
	// 
	// emp_id
	// 
	this.emp_id.DataPropertyName = "EmpID";
	this.emp_id.HeaderText = "Emp ID";
	this.emp_id.Name = "emp_id";
	// 
	// firstname
	// 
	this.firstname.DataPropertyName = "FirstName";
	this.firstname.HeaderText = "First Name";
	this.firstname.Name = "firstname";
	// 
	// lastname
	// 
	this.lastname.DataPropertyName = "LastName";
	this.lastname.HeaderText = "Last name";
	this.lastname.Name = "lastname";
	// 
	// emp_id_para0
	// 
	this.emp_id_para0.Location = new System.Drawing.Point(258, 21);
	this.emp_id_para0.Name = "emp_id_para0";
	this.emp_id_para0.Size = new System.Drawing.Size(140, 91);
	this.emp_id_para0.TabIndex = 4;
	this.emp_id_para0.Text = "Examples : 850297, 304721,  412317, 621375, 252938, 265124, 308617";
	// 
	// debug_button0
	// 
	this.debug_button0.Location = new System.Drawing.Point(9, 44);
	this.debug_button0.Name = "debug_button0";
	this.debug_button0.Size = new System.Drawing.Size(95, 23);
	this.debug_button0.TabIndex = 0;
	this.debug_button0.Text = "Debug Test";
	this.debug_button0.UseVisualStyleBackColor = true;
	this.debug_button0.Click += new System.EventHandler(this.debug_button0_Click);
	// 
	// joindate_button0
	// 
	this.joindate_button0.Location = new System.Drawing.Point(258, 23);
	this.joindate_button0.Name = "joindate_button0";
	this.joindate_button0.Size = new System.Drawing.Size(135, 23);
	this.joindate_button0.TabIndex = 7;
	this.joindate_button0.Text = "Output Result";
	this.joindate_button0.UseVisualStyleBackColor = true;
	this.joindate_button0.Click += new System.EventHandler(this.joindate_button0_Click);
	// 
	// group_employees_5years
	// 
	this.group_employees_5years.Controls.Add(this.label8);
	this.group_employees_5years.Controls.Add(this.button_city_list0);
	this.group_employees_5years.Controls.Add(this.button_buck0);
	this.group_employees_5years.Controls.Add(this.label7);
	this.group_employees_5years.Controls.Add(this.button_treasure0);
	this.group_employees_5years.Controls.Add(this.label6);
	this.group_employees_5years.Controls.Add(this.button_fetch_female_salary);
	this.group_employees_5years.Controls.Add(this.label2);
	this.group_employees_5years.Controls.Add(this.button_salary_gender0);
	this.group_employees_5years.Controls.Add(this.button1);
	this.group_employees_5years.Controls.Add(this.label_salary_gender0);
	this.group_employees_5years.Controls.Add(this.label_fetch_age);
	this.group_employees_5years.Controls.Add(this.label_employee5years);
	this.group_employees_5years.Controls.Add(this.joindate_button0);
	this.group_employees_5years.Location = new System.Drawing.Point(452, 24);
	this.group_employees_5years.Name = "group_employees_5years";
	this.group_employees_5years.Size = new System.Drawing.Size(440, 279);
	this.group_employees_5years.TabIndex = 8;
	this.group_employees_5years.TabStop = false;
	this.group_employees_5years.Text = "Special Exercise Section";
	// 
	// button_fetch_female_salary
	// 
	this.button_fetch_female_salary.Location = new System.Drawing.Point(258, 125);
	this.button_fetch_female_salary.Name = "button_fetch_female_salary";
	this.button_fetch_female_salary.Size = new System.Drawing.Size(135, 23);
	this.button_fetch_female_salary.TabIndex = 14;
	this.button_fetch_female_salary.Text = "Output Female";
	this.button_fetch_female_salary.UseVisualStyleBackColor = true;
	this.button_fetch_female_salary.Click += new System.EventHandler(this.button_fetch_female_salary_Click);
	// 
	// label2
	// 
	this.label2.AutoSize = true;
	this.label2.Location = new System.Drawing.Point(7, 135);
	this.label2.Name = "label2";
	this.label2.Size = new System.Drawing.Size(200, 13);
	this.label2.TabIndex = 13;
	this.label2.Text = "Fetch female employees with highest pay";
	// 
	// button_salary_gender0
	// 
	this.button_salary_gender0.Location = new System.Drawing.Point(258, 86);
	this.button_salary_gender0.Name = "button_salary_gender0";
	this.button_salary_gender0.Size = new System.Drawing.Size(135, 23);
	this.button_salary_gender0.TabIndex = 12;
	this.button_salary_gender0.Text = "Output Male";
	this.button_salary_gender0.UseVisualStyleBackColor = true;
	this.button_salary_gender0.Click += new System.EventHandler(this.button_salary_gender0_Click);
	// 
	// button1
	// 
	this.button1.Location = new System.Drawing.Point(258, 53);
	this.button1.Name = "button1";
	this.button1.Size = new System.Drawing.Size(135, 23);
	this.button1.TabIndex = 11;
	this.button1.Text = "Output Result";
	this.button1.UseVisualStyleBackColor = true;
	this.button1.Click += new System.EventHandler(this.button1_Click);
	// 
	// label_salary_gender0
	// 
	this.label_salary_gender0.AutoSize = true;
	this.label_salary_gender0.Location = new System.Drawing.Point(6, 91);
	this.label_salary_gender0.Name = "label_salary_gender0";
	this.label_salary_gender0.Size = new System.Drawing.Size(191, 13);
	this.label_salary_gender0.TabIndex = 10;
	this.label_salary_gender0.Text = "Fetch male employees with highest pay";
	// 
	// label_fetch_age
	// 
	this.label_fetch_age.AutoSize = true;
	this.label_fetch_age.Location = new System.Drawing.Point(7, 58);
	this.label_fetch_age.Name = "label_fetch_age";
	this.label_fetch_age.Size = new System.Drawing.Size(152, 13);
	this.label_fetch_age.TabIndex = 9;
	this.label_fetch_age.Text = "Fetch employees older than 30";
	// 
	// label_employee5years
	// 
	this.label_employee5years.AutoSize = true;
	this.label_employee5years.Location = new System.Drawing.Point(7, 28);
	this.label_employee5years.Name = "label_employee5years";
	this.label_employee5years.Size = new System.Drawing.Size(245, 13);
	this.label_employee5years.TabIndex = 8;
	this.label_employee5years.Text = "Fetch employees who joined company 5 years ago";
	// 
	// label3
	// 
	this.label3.AutoSize = true;
	this.label3.Location = new System.Drawing.Point(21, 244);
	this.label3.Name = "label3";
	this.label3.Size = new System.Drawing.Size(49, 13);
	this.label3.TabIndex = 9;
	this.label3.Text = "Surname";
	// 
	// label4
	// 
	this.label4.AutoSize = true;
	this.label4.Location = new System.Drawing.Point(21, 218);
	this.label4.Name = "label4";
	this.label4.Size = new System.Drawing.Size(57, 13);
	this.label4.TabIndex = 10;
	this.label4.Text = "First Name";
	// 
	// label5
	// 
	this.label5.AutoSize = true;
	this.label5.Location = new System.Drawing.Point(21, 273);
	this.label5.Name = "label5";
	this.label5.Size = new System.Drawing.Size(24, 13);
	this.label5.TabIndex = 11;
	this.label5.Text = "City";
	// 
	// input_name0
	// 
	this.input_name0.Location = new System.Drawing.Point(94, 218);
	this.input_name0.Name = "input_name0";
	this.input_name0.Size = new System.Drawing.Size(138, 20);
	this.input_name0.TabIndex = 12;
	this.input_name0.TextChanged += new System.EventHandler(this.input_name0_TextChanged);
	// 
	// input_surname0
	// 
	this.input_surname0.Location = new System.Drawing.Point(94, 244);
	this.input_surname0.Name = "input_surname0";
	this.input_surname0.Size = new System.Drawing.Size(138, 20);
	this.input_surname0.TabIndex = 13;
	this.input_surname0.TextChanged += new System.EventHandler(this.input_surname0_TextChanged);
	// 
	// input_city0
	// 
	this.input_city0.Location = new System.Drawing.Point(94, 273);
	this.input_city0.Name = "input_city0";
	this.input_city0.Size = new System.Drawing.Size(138, 20);
	this.input_city0.TabIndex = 14;
	this.input_city0.TextChanged += new System.EventHandler(this.input_city0_TextChanged);
	// 
	// dataGrid_city0
	// 
	this.dataGrid_city0.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
	this.dataGrid_city0.Location = new System.Drawing.Point(21, 307);
	this.dataGrid_city0.Name = "dataGrid_city0";
	this.dataGrid_city0.Size = new System.Drawing.Size(824, 131);
	this.dataGrid_city0.TabIndex = 15;
	this.dataGrid_city0.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGrid_city0_CellContentClick);
	// 
	// button_search_criteria0
	// 
	this.button_search_criteria0.Location = new System.Drawing.Point(282, 269);
	this.button_search_criteria0.Name = "button_search_criteria0";
	this.button_search_criteria0.Size = new System.Drawing.Size(158, 23);
	this.button_search_criteria0.TabIndex = 16;
	this.button_search_criteria0.Text = "Search Employees";
	this.button_search_criteria0.UseVisualStyleBackColor = true;
	this.button_search_criteria0.Click += new System.EventHandler(this.button_search_criteria0_Click);
	// 
	// label6
	// 
	this.label6.AutoSize = true;
	this.label6.Location = new System.Drawing.Point(7, 167);
	this.label6.Name = "label6";
	this.label6.Size = new System.Drawing.Size(224, 13);
	this.label6.TabIndex = 15;
	this.label6.Text = "Fetch Salaries of Employees named \'Treasure\'";
	// 
	// button_treasure0
	// 
	this.button_treasure0.Location = new System.Drawing.Point(258, 156);
	this.button_treasure0.Name = "button_treasure0";
	this.button_treasure0.Size = new System.Drawing.Size(135, 23);
	this.button_treasure0.TabIndex = 16;
	this.button_treasure0.Text = "Output Treasure";
	this.button_treasure0.UseVisualStyleBackColor = true;
	this.button_treasure0.Click += new System.EventHandler(this.button_treasure0_Click);
	// 
	// label7
	// 
	this.label7.AutoSize = true;
	this.label7.Location = new System.Drawing.Point(7, 195);
	this.label7.Name = "label7";
	this.label7.Size = new System.Drawing.Size(211, 13);
	this.label7.TabIndex = 17;
	this.label7.Text = "Fetch Salaries for Employees named \'Nona\'";
	// 
	// button_buck0
	// 
	this.button_buck0.Location = new System.Drawing.Point(258, 190);
	this.button_buck0.Name = "button_buck0";
	this.button_buck0.Size = new System.Drawing.Size(135, 23);
	this.button_buck0.TabIndex = 18;
	this.button_buck0.Text = "Output Nona";
	this.button_buck0.UseVisualStyleBackColor = true;
	this.button_buck0.Click += new System.EventHandler(this.button_buck0_Click);
	// 
	// button_city_list0
	// 
	this.button_city_list0.Location = new System.Drawing.Point(258, 220);
	this.button_city_list0.Name = "button_city_list0";
	this.button_city_list0.Size = new System.Drawing.Size(135, 23);
	this.button_city_list0.TabIndex = 19;
	this.button_city_list0.Text = "List Cities";
	this.button_city_list0.UseVisualStyleBackColor = true;
	this.button_city_list0.Click += new System.EventHandler(this.button_city_list0_Click);
	// 
	// label8
	// 
	this.label8.AutoSize = true;
	this.label8.Location = new System.Drawing.Point(7, 226);
	this.label8.Name = "label8";
	this.label8.Size = new System.Drawing.Size(109, 13);
	this.label8.TabIndex = 20;
	this.label8.Text = "List all the City Entries";
	// 
	// SecondForm
	// 
	this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
	this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
	this.ClientSize = new System.Drawing.Size(964, 457);
	this.Controls.Add(this.button_search_criteria0);
	this.Controls.Add(this.dataGrid_city0);
	this.Controls.Add(this.input_city0);
	this.Controls.Add(this.input_surname0);
	this.Controls.Add(this.input_name0);
	this.Controls.Add(this.label5);
	this.Controls.Add(this.label4);
	this.Controls.Add(this.label3);
	this.Controls.Add(this.group_employees_5years);
	this.Controls.Add(this.emp_id_box);
	this.Name = "SecondForm";
	this.Text = "SecondForm";
	this.emp_id_box.ResumeLayout(false);
	this.emp_id_box.PerformLayout();
	((System.ComponentModel.ISupportInitialize)(this.emp_id_output0)).EndInit();
	this.group_employees_5years.ResumeLayout(false);
	this.group_employees_5years.PerformLayout();
	((System.ComponentModel.ISupportInitialize)(this.dataGrid_city0)).EndInit();
	this.ResumeLayout(false);
	this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox input_1;
        private System.Windows.Forms.Button get_id_button0;
        private System.Windows.Forms.GroupBox emp_id_box;
        private System.Windows.Forms.Label emp_id_para0;
        private System.Windows.Forms.DataGridView emp_id_output0;
        private System.Windows.Forms.DataGridViewTextBoxColumn emp_id;
        private System.Windows.Forms.DataGridViewTextBoxColumn firstname;
        private System.Windows.Forms.DataGridViewTextBoxColumn lastname;
        private System.Windows.Forms.Button debug_button0;
        private System.Windows.Forms.Button joindate_button0;
        private System.Windows.Forms.GroupBox group_employees_5years;
        private System.Windows.Forms.Label label_employee5years;
  private System.Windows.Forms.Button button_salary_gender0;
  private System.Windows.Forms.Button button1;
  private System.Windows.Forms.Label label_salary_gender0;
  private System.Windows.Forms.Label label_fetch_age;
  private System.Windows.Forms.Button button_fetch_female_salary;
  private System.Windows.Forms.Label label2;
  private System.Windows.Forms.Label label3;
  private System.Windows.Forms.Label label4;
  private System.Windows.Forms.Label label5;
  private System.Windows.Forms.TextBox input_name0;
  private System.Windows.Forms.TextBox input_surname0;
  private System.Windows.Forms.TextBox input_city0;
  private System.Windows.Forms.DataGridView dataGrid_city0;
  private System.Windows.Forms.Button button_search_criteria0;
  private System.Windows.Forms.Button button_treasure0;
  private System.Windows.Forms.Label label6;
  private System.Windows.Forms.Button button_buck0;
  private System.Windows.Forms.Label label7;
  private System.Windows.Forms.Label label8;
  private System.Windows.Forms.Button button_city_list0;
 }
}