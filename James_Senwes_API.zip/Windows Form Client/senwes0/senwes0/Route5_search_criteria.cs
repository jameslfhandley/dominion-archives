﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Web;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Collections;
using System.IO;
using System.Net;


namespace senwes0
{
 public class Route5_search_criteria
 {

  public Route5_search_criteria(string arg1,string arg2,string arg3,ref DataGridView Datasource0, ref string port_no0)
  {
   string compare0 = "";
   string compare1 = "";
   string compare2 = "";
   if (arg1 != null)
   {
    compare0 = arg1.ToLower();
    compare0 = HttpUtility.UrlEncode(compare0);
   }
   else
   {
    compare0 = "void";
   }
   if (arg2 != null)
   {
    compare1 = arg2.ToLower();
    compare1 = HttpUtility.UrlEncode(compare1);
   }
   else
   {
    compare1 = "void";
   }

   if (arg3 != null)
   {
    compare2 = arg3.ToLower();
    compare2 = HttpUtility.UrlEncode(compare2);
   }
   else
   {
    compare2 = "void";
   }

   List<Employee> empdata0;
   string build_parameters = "https://localhost:" + port_no0 + "/route1/fetch_emp_search?fname=" + compare0 + "&lname=" + compare1 + "&city=" + compare2;
   string convert0 = "";
   var json1 = new WebClient().DownloadString(build_parameters);

   convert0 = json1;
   empdata0 = JsonConvert.DeserializeObject<List<Employee>>(json1);


   Datasource0.DataSource = empdata0;
  }

 }
}
