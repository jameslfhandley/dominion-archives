﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace senwes0
{
 public class City_form1
 {

  public City_form1()
  {

  }

  public City_form1(string City0)
  {
	this.City = City0;
  }

  public string City { get; set; }

 }


}
