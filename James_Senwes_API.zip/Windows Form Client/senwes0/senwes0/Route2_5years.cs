﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace senwes0
{
 public class Route2_5years
 {
  public Route2_5years(ref DataGridView Datasource, ref string port_no0)
  {
   List<Employee> empdata0;
   string convert0 = "";
   var json1 = new WebClient().DownloadString("https://localhost:" + port_no0 + "/route2/fetch_five");

   convert0 = json1;
   empdata0 = JsonConvert.DeserializeObject<List<Employee>>(json1);
   Datasource.DataSource = empdata0;
  }
 }

}
