﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using Newtonsoft.Json;


namespace senwes0
{
 public class Route4_select_gender
 {
  public Route4_select_gender(string gender,ref DataGridView Datasource0, ref string port_no0)
  {
   List<Employee> empdata0;
   string convert0 = "";
   var json1 = new WebClient().DownloadString("https://localhost:" + port_no0 + "/route3/" + gender);

   convert0 = json1;
   empdata0 = JsonConvert.DeserializeObject<List<Employee>>(json1);
   Datasource0.DataSource = empdata0;

    }

   }
  }